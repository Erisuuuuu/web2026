n, m = map(int, input().split())
arr = list(map(int, input().split()))
A = set(map(int, input().split()))
B = set(map(int, input().split()))
mood = 0
for i in arr:
    if i in A:
        mood += 1
    elif i in B:
        mood -= 1
print(mood)
