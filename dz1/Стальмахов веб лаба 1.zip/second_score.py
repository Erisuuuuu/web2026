n = int(input())
arr = list(map(int, input().split()))
s = sorted(set(arr))

if len(s) >= 2:
    print(s[-2])
else:
    print(s[-1])
