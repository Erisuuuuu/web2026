s = input()
res = []
for c in s:
    if c.isupper():
        res.append(c.lower())
    elif c.islower():
        res.append(c.upper())
    else:
        res.append(c)
print("".join(res))
