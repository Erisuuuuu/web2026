def compute_average_scores(scores):
    n = len(scores[0])
    result = []
    for i in range(n):
        s = sum(t[i] for t in scores)
        result.append(round(s / len(scores), 1))
    return tuple(result)

if __name__ == '__main__':
    n, x = map(int, input().split())
    scores = [tuple(map(float, input().split())) for _ in range(x)]
    for v in compute_average_scores(scores):
        print(v)
